package task1;

/*
这是我的第一个Java程序，输出“世界，你好！”
 */
public class HelloWorld {
    //添加主方法---psvm+回车
    public static void main(String[] args) {
        //输出后换行---sout+回车
        System.out.print("世界，你好！\n");//输出后不换行---print(); '\n'---换行符
        System.out.println("我是黄俊博，这是我的第一个Java程序");//字符串写法：""---半角的，编程语言的符号都是这样
    }
}
