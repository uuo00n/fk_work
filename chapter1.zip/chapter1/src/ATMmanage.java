/*
这个包会在默认包里---没有package语句
编程练习1-1 输出ATM界面
copyright：23软件(3+2)一班黄俊博
 */
public class ATMmanage {
    public static void main(String[] args) {
        System.out.println("我是23软件(3+2)一班黄俊博");
        System.out.println("---欢迎使用ATM存取款系统---");
        System.out.println("1.存款");
        System.out.println("2.取款");
        System.out.println("3.查询余额");
        System.out.println("4.退出");
        System.out.println("请输入你的选择(1~4)");
    }
}
